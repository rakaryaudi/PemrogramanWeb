<!DOCTYPE html>
<html>
<body>

<?php
echo strtolower("Hello WORLD.");
?>
   
</body>
</html>