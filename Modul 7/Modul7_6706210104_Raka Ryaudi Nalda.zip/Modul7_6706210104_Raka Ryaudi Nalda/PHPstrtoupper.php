<!DOCTYPE html>
<html>
<body>

<?php
echo strtoupper("Hello WORLD!");
?> 
 
</body>
</html>