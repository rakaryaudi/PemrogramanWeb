<!DOCTYPE html>
<html>
<body>

<?php
$arr = array('Hello','World!','Beautiful','Day!');
echo implode(" ",$arr);
?>

</body>
</html>