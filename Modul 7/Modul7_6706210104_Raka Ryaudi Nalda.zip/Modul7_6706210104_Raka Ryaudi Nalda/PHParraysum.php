<!DOCTYPE html>
<html>
<body>

<?php
$a=array(5,15,25);
echo array_sum($a);
?>

</body>
</html>