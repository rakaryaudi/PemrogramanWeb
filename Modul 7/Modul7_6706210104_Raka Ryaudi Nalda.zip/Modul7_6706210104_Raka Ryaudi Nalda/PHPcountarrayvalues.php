<!DOCTYPE html>
<html>
<body>

<?php
$a=array("A","Cat","Dog","A","Dog");
print_r(array_count_values($a));
?>

</body>
</html>