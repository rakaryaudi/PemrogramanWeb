<!DOCTYPE html>
<html>
<body>

<?php
echo strlen("Hello");
?>

</body>
</html>