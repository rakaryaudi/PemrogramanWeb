<!DOCTYPE html>
<html>
<body>

<?php
$str = "Hello world. It's a beautiful day.";
print_r (explode(" ",$str));
?> 

</body>
</html>